from setuptools import setup

__version__ = "alpha"

long_description="""This is a very nice package 

"""

setup(name='constants',
      version=__version__,
      description='A very nice package',
      author=u'François Pignon',
      author_email='francois.pignon@trucmuch.fr',
      url='',
      packages=['constants'],
     )

