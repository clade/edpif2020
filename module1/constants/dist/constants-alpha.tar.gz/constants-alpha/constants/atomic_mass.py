rubidium_87 = 86.909180527

