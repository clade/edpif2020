from math import pi

c = 299792458
e = 1.60217663E-19
h = 6.62607015E-34
hbar = h/(2*pi)
mu_0= 1.25663706212E-6


